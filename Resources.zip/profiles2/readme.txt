NOTE: 

Please copy a profile before you edit it. 
The delivered profiles will be overwritten when the lookups.dat changes.


WARNING:

Since Android Q (29) the storage folder for BRouter is a app specific folder.
It will be removed when BRouter is uninstalled or the data is cleared (system settings/apps).
